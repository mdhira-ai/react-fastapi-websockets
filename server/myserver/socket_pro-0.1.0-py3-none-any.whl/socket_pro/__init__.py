from fastapi import FastAPI, WebSocket
from typing import List
import json


class socketio:

    def __init__(self):
        self.active_clients: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_clients.append(websocket)

    async def disconnect(self, websocket: WebSocket):
        self.active_clients.remove(websocket)

    async def broadcast(self, data_type: str, data: str):
        send_data = json.dumps({
            "data_type": data_type,
            "data": data
        })

        for allclient in self.active_clients:
            await allclient.send_text(send_data)
